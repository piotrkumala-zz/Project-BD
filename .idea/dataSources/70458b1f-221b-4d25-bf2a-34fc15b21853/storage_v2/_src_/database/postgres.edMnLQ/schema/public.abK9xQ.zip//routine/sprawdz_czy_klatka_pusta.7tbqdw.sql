create function sprawdz_czy_klatka_pusta(integer) returns boolean
    language plpgsql
as
$$
DECLARE
        out bool;
        ile int;
        max int;
    BEGIN
        ile = COUNT(*) FROM szczury WHERE id_kl =$1;
        max = rk.maksymalnapojemnosc FROM rodzajeklatek rk, klatka kl WHERE kl.id_kl = $1 AND kl.id_rk =rk.id_rk;
        IF ile <max THEN
            out = true;
            ELSE
            out = false;
        end if;
        RETURN out;
    end;
$$;

alter function sprawdz_czy_klatka_pusta(integer) owner to postgres;

