create function czy_login_zajety(text) returns boolean
    language plpgsql
as
$$
BEGIN
        IF EXISTS(SELECT * FROM klienci WHERE email = $1) THEN
            return true;
        end if;
        IF EXISTS(SELECT * FROM pracownicy WHERE login = $1) THEN
            return true;
        end if;
        return false;
    end;
$$;

alter function czy_login_zajety(text) owner to postgres;

