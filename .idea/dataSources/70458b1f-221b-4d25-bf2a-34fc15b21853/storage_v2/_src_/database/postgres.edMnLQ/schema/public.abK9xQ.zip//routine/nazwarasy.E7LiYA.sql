create function nazwarasy(integer) returns text
    language plpgsql
as
$$
DECLARE
        r rasy%rowtype;
        out text;
    BEGIN
        FOR r IN SELECT * FROM rasy LOOP
            IF r.id_r = $1
                THEN out = r.nazwa;

            end if;
            end loop;

        RETURN out;

    END;
$$;

alter function nazwarasy(integer) owner to postgres;

