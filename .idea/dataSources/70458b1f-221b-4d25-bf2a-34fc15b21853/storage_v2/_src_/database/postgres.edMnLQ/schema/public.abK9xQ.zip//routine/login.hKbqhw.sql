create function login(text, text) returns SETOF mytype
    language plpgsql
as
$$
DECLARE
        loginek ALIAS FOR $1;
        haslo ALIAS FOR $2;
        _r mytype;
    BEGIN
        IF EXISTS(SELECT * FROM pracownicy p WHERE p.login =loginek) = true THEN
            FOR _r IN
                SELECT p.id_p, 'Pracownik', p.login, p.haslo FROM pracownicy p WHERE p.login = loginek
            LOOP
                IF _r.haslo = haslo THEN
                    RETURN NEXT _r;
                end if;
            end loop;
        end if;

        IF EXISTS(SELECT * FROM klienci kl WHERE kl.email =loginek) = true THEN
            FOR _r IN
            SELECT kl.id_klienta, 'Klient', kl.email, kl.haslo FROM klienci kl WHERE kl.email = loginek
            LOOP
                RAISE NOTICE '%', _r.haslo = haslo;
                IF _r.haslo = haslo THEN
                    RETURN NEXT _r ;
                end if;
            end loop;
        end if;
    end;
$$;

alter function login(text, text) owner to postgres;

