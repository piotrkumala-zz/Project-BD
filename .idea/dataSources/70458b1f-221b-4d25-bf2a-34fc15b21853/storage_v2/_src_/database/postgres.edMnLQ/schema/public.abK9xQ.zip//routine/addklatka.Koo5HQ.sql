create function addklatka(integer, integer) returns void
    language sql
as
$$
INSERT INTO klatka (id_rk, id_p) VALUES ($1,$2);
        INSERT INTO czynnoscikonserwacyjne (ostatniesprzatanie, wizytauweterynarza, ostatniwybieg, id_kl)
        VALUES ('01-01-1980', '01-01-1980', '01-01-1980', currval('klatka_id_kl_seq_1_1'));
$$;

alter function addklatka(integer, integer) owner to postgres;

