create function czy_moze_zamowic(integer) returns boolean
    language plpgsql
as
$$
DECLARE
        _r test%rowtype;
    BEGIN
        FOR _r IN SELECT * FROM test WHERE id_klienta = $1 LOOP
            IF(_r.wynik>=50) THEN
                RETURN TRUE;
            end if;
        end loop;
        RETURN false;
    end;
$$;

alter function czy_moze_zamowic(integer) owner to postgres;

