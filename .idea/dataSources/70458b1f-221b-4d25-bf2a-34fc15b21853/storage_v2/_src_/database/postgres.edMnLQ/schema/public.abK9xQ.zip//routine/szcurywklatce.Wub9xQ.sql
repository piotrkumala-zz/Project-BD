create function szcurywklatce(integer) returns SETOF szczury
    language plpgsql
as
$$
DECLARE
            r szczury%rowtype;
        BEGIN
            FOR r IN
                SELECT * FROM szczury  WHERE id_kl = $1
            LOOP
                RETURN NEXT r;
                END LOOP;
            RETURN;
        END;
$$;

alter function szcurywklatce(integer) owner to postgres;

